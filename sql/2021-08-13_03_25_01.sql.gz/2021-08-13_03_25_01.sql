--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE frizerrose;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md508cfe0a23f5d458787e4478c6c75158c';






--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6 (Debian 12.6-1.pgdg100+1)
-- Dumped by pg_dump version 12.6 (Debian 12.6-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "frizerrose" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6 (Debian 12.6-1.pgdg100+1)
-- Dumped by pg_dump version 12.6 (Debian 12.6-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: frizerrose; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE frizerrose WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE frizerrose OWNER TO postgres;

\connect frizerrose

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointment (
    id integer NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    message text NOT NULL,
    "hasSentStaffEmail" boolean DEFAULT false NOT NULL,
    "hasSentCustomerEmail" boolean DEFAULT false NOT NULL,
    "hasCustomerArrived" boolean DEFAULT true NOT NULL,
    "companyId" integer,
    "staffId" integer,
    "serviceId" integer,
    "customerId" integer
);


ALTER TABLE public.appointment OWNER TO postgres;

--
-- Name: appointment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointment_id_seq OWNER TO postgres;

--
-- Name: appointment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointment_id_seq OWNED BY public.appointment.id;


--
-- Name: break; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.break (
    id integer NOT NULL,
    start date NOT NULL,
    "end" date NOT NULL,
    "staffId" integer
);


ALTER TABLE public.break OWNER TO postgres;

--
-- Name: break_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.break_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.break_id_seq OWNER TO postgres;

--
-- Name: break_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.break_id_seq OWNED BY public.break.id;


--
-- Name: company; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company (
    id integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    "bookingPageSlug" character varying(255) NOT NULL,
    oib character varying(255) DEFAULT ''::character varying NOT NULL,
    "contactEmail" character varying(255) DEFAULT ''::character varying NOT NULL,
    "streetName" character varying(255) DEFAULT ''::character varying NOT NULL,
    city character varying(255) DEFAULT ''::character varying NOT NULL,
    "phoneNumber" character varying(255) DEFAULT ''::character varying NOT NULL,
    about text DEFAULT ''::text NOT NULL,
    "hasSentTrialEndEmail" boolean DEFAULT false NOT NULL,
    hours text NOT NULL
);


ALTER TABLE public.company OWNER TO postgres;

--
-- Name: companyPreferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."companyPreferences" (
    id integer NOT NULL,
    "leadTimeWindow" integer DEFAULT 3 NOT NULL,
    "schedulingWindow" integer DEFAULT 30 NOT NULL,
    "cancellationWindow" integer DEFAULT 2 NOT NULL,
    "hasStaffPick" boolean DEFAULT true NOT NULL,
    "hasSexPick" boolean DEFAULT false NOT NULL,
    "hasBorders" boolean DEFAULT false NOT NULL,
    "canCancel" boolean DEFAULT true NOT NULL,
    "showRules" boolean DEFAULT true NOT NULL,
    "showCoronaRules" boolean DEFAULT true NOT NULL,
    "clientReminderEmail" boolean DEFAULT true NOT NULL,
    "staffReminderEmail" boolean DEFAULT true NOT NULL,
    "staffCancellationNotice" boolean DEFAULT true NOT NULL,
    "isTutorialFinished" boolean DEFAULT false NOT NULL,
    "hasDarkMode" boolean DEFAULT false NOT NULL,
    "clientReminderTime" integer DEFAULT 2 NOT NULL,
    "staffReminderTime" integer DEFAULT 2 NOT NULL,
    "colorVariant" character varying(255) DEFAULT 'default'::character varying NOT NULL,
    "hasPattern" boolean DEFAULT false NOT NULL,
    "showTerms" boolean DEFAULT false NOT NULL,
    "facebookLink" character varying(255) DEFAULT ''::character varying NOT NULL,
    "instagramLink" character varying(255) DEFAULT ''::character varying NOT NULL,
    "websiteLink" character varying(255) DEFAULT ''::character varying NOT NULL,
    "termsText" text DEFAULT ''::text NOT NULL,
    rules text DEFAULT ''::text NOT NULL,
    "coronaRules" text DEFAULT ''::text NOT NULL,
    "companyId" integer
);


ALTER TABLE public."companyPreferences" OWNER TO postgres;

--
-- Name: companyPreferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."companyPreferences_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."companyPreferences_id_seq" OWNER TO postgres;

--
-- Name: companyPreferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."companyPreferences_id_seq" OWNED BY public."companyPreferences".id;


--
-- Name: company_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_id_seq OWNER TO postgres;

--
-- Name: company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.company_id_seq OWNED BY public.company.id;


--
-- Name: contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    body text NOT NULL,
    "companyId" integer
);


ALTER TABLE public.contact OWNER TO postgres;

--
-- Name: contact_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_id_seq OWNER TO postgres;

--
-- Name: contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_id_seq OWNED BY public.contact.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    phone character varying(255) DEFAULT ''::character varying NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    "companyId" integer
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_id_seq OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: dayOff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."dayOff" (
    id integer NOT NULL,
    start date NOT NULL,
    "end" date NOT NULL,
    "companyId" integer
);


ALTER TABLE public."dayOff" OWNER TO postgres;

--
-- Name: dayOff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."dayOff_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."dayOff_id_seq" OWNER TO postgres;

--
-- Name: dayOff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."dayOff_id_seq" OWNED BY public."dayOff".id;


--
-- Name: faq; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faq (
    id integer NOT NULL,
    question character varying(255) NOT NULL,
    answer text NOT NULL,
    category text DEFAULT ''::text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.faq OWNER TO postgres;

--
-- Name: faq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faq_id_seq OWNER TO postgres;

--
-- Name: faq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faq_id_seq OWNED BY public.faq.id;


--
-- Name: image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.image (
    id integer NOT NULL,
    link character varying(255) NOT NULL,
    "companyId" integer,
    "staffId" integer
);


ALTER TABLE public.image OWNER TO postgres;

--
-- Name: image_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.image_id_seq OWNER TO postgres;

--
-- Name: image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.image_id_seq OWNED BY public.image.id;


--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    id integer NOT NULL,
    status character varying DEFAULT 'processing'::character varying NOT NULL,
    date date NOT NULL,
    "companyId" integer
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_id_seq OWNER TO postgres;

--
-- Name: payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_id_seq OWNED BY public.payment.id;


--
-- Name: service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    duration integer NOT NULL,
    price integer NOT NULL,
    sex character varying(255) DEFAULT 'both'::character varying NOT NULL,
    "companyId" integer
);


ALTER TABLE public.service OWNER TO postgres;

--
-- Name: service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_id_seq OWNER TO postgres;

--
-- Name: service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_id_seq OWNED BY public.service.id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    email character varying(255) NOT NULL,
    hours text NOT NULL,
    "companyId" integer,
    "userId" integer
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_id_seq OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_id_seq OWNED BY public.staff.id;


--
-- Name: staff_services_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_services_service (
    "staffId" integer NOT NULL,
    "serviceId" integer NOT NULL
);


ALTER TABLE public.staff_services_service OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "isAdminAccount" boolean DEFAULT false NOT NULL,
    password character varying(255) NOT NULL,
    "companyId" integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: appointment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment ALTER COLUMN id SET DEFAULT nextval('public.appointment_id_seq'::regclass);


--
-- Name: break id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break ALTER COLUMN id SET DEFAULT nextval('public.break_id_seq'::regclass);


--
-- Name: company id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company ALTER COLUMN id SET DEFAULT nextval('public.company_id_seq'::regclass);


--
-- Name: companyPreferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."companyPreferences" ALTER COLUMN id SET DEFAULT nextval('public."companyPreferences_id_seq"'::regclass);


--
-- Name: contact id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact ALTER COLUMN id SET DEFAULT nextval('public.contact_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: dayOff id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."dayOff" ALTER COLUMN id SET DEFAULT nextval('public."dayOff_id_seq"'::regclass);


--
-- Name: faq id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faq ALTER COLUMN id SET DEFAULT nextval('public.faq_id_seq'::regclass);


--
-- Name: image id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image ALTER COLUMN id SET DEFAULT nextval('public.image_id_seq'::regclass);


--
-- Name: payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment ALTER COLUMN id SET DEFAULT nextval('public.payment_id_seq'::regclass);


--
-- Name: service id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service ALTER COLUMN id SET DEFAULT nextval('public.service_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN id SET DEFAULT nextval('public.staff_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: appointment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointment (id, date, "time", message, "hasSentStaffEmail", "hasSentCustomerEmail", "hasCustomerArrived", "companyId", "staffId", "serviceId", "customerId") FROM stdin;
1	2021-05-11	15:30:00		t	t	t	1	1	6	1
3	2021-05-12	08:00:00		t	t	t	3	5	8	3
5	2021-05-12	08:45:00		t	t	t	3	5	22	3
7	2021-05-27	11:15:00		t	t	t	1	1	1	1
6	2021-05-29	08:00:00		t	t	t	3	5	26	4
\.


--
-- Data for Name: break; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.break (id, start, "end", "staffId") FROM stdin;
\.


--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company (id, "createdAt", name, "isPublic", "bookingPageSlug", oib, "contactEmail", "streetName", city, "phoneNumber", about, "hasSentTrialEndEmail", hours) FROM stdin;
4	2021-05-19 07:07:11.128376	svekrva	t	svekrva		1obicnimail@gmail.com					t	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
5	2021-05-26 18:39:18.77982	Marko	t	primjer-marko		ronca85@gmail.com					t	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
6	2021-06-08 14:32:14.717908	Alex oaza ljepote	t	alex-oaza-ljepote		Alexoazaljepote@gmail.com					t	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
1	2021-05-08 15:23:22.342101	Frizerski Salon Trešnja	t	tresnja		jurajmarkesic@gmail.com	Marka Marulića 1	Zagreb	385 283472234	ABout text	t	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"14:00"}]},"thursday":{"active":false,"shifts":[]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
2	2021-05-11 09:11:04.963758	Frizerski Salon Marelica	t	marelica		juraj@dolazim.hr					t	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
3	2021-05-11 13:43:28.669067	Frizerski salon Barbara	t	primjer-stranica		podrska@dolazim.hr	Glavna ulica 45	Bjelovar	+385 (99) 00 00 000	Poslujemo od 2004., a od 2021. naše usluge nudimo na webu.\nSamo trebate odabrati uslugu, termin koji vam odgovara i e-mail adresu na koju vam stiže potvrda.\nVidimo se!	t	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
\.


--
-- Data for Name: companyPreferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."companyPreferences" (id, "leadTimeWindow", "schedulingWindow", "cancellationWindow", "hasStaffPick", "hasSexPick", "hasBorders", "canCancel", "showRules", "showCoronaRules", "clientReminderEmail", "staffReminderEmail", "staffCancellationNotice", "isTutorialFinished", "hasDarkMode", "clientReminderTime", "staffReminderTime", "colorVariant", "hasPattern", "showTerms", "facebookLink", "instagramLink", "websiteLink", "termsText", rules, "coronaRules", "companyId") FROM stdin;
2	3	30	2	f	f	f	t	t	t	t	t	t	t	f	2	2	default	f	f							2
1	3	30	2	t	f	f	t	t	t	t	t	t	t	f	3	4	default	f	t	https://abc.com	https://abc.com	https://abc.com	sdfsd fs dfs\ndf \nsd\n fs\nd f\n sd\nf \n	fsdfs df\ns d\nfs d\nf\n sdf	sd fs\nd f\ns dd\nf 	1
3	3	30	2	t	f	f	t	t	t	t	t	t	t	f	2	2	default	t	f	https://www.facebook.com/primjer-stranica-barbara	https://www.instagram.com/primjer-stranica-barbara	https://www.primjer-stranica-barbara.hr		Dođite na vrijeme, što znači barem 5 minuta prije termina. Ponesite točan iznos u kunama. To anm puno znači.	Ponesite maskicu.	3
4	3	30	2	t	f	f	t	t	t	t	t	t	t	f	2	2	default	f	f							4
5	3	30	2	f	f	t	f	t	t	t	t	t	t	t	2	2	goldenrod	t	f			https://ronca85.github.io/folio				5
6	3	30	2	t	f	f	t	t	t	t	t	t	f	f	2	2	default	f	f							6
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact (id, name, email, body, "companyId") FROM stdin;
1	Mrs. Anita Bogan	jerad.ullrich@yahoo.com	compress	\N
2	Mrs. Anita Bogan	jerad.ullrich@yahoo.com	compress	\N
3	Salvatore Kovacek	matp36@yahoo.com	SSL	\N
4	Salvatore Kovacek	matp36@yahoo.com	SSL	\N
5	Sasha Jerde	winnfernandes24@gmail.com	Incredible	\N
6	Sasha Jerde	winnfernandes24@gmail.com	Incredible	\N
7	Allan Von	m.meejoo@gmail.com	system	\N
8	Allan Von	m.meejoo@gmail.com	system	\N
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, name, email, phone, notes, "companyId") FROM stdin;
2	Marko Ronik	marko.ronik@gmail.com			1
3	Ante	demo-klijent-ante@example.com			3
4	Irma Aletić	aletic2703@gmail.com			3
1	Juraj Markešić	jurajmarkesic@gmail.com	0953984635		1
\.


--
-- Data for Name: dayOff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."dayOff" (id, start, "end", "companyId") FROM stdin;
\.


--
-- Data for Name: faq; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faq (id, question, answer, category, "order") FROM stdin;
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.image (id, link, "companyId", "staffId") FROM stdin;
2	https://frizerrose-images.fra1.digitaloceanspaces.com/1620723689311%20-%20barber-shop-logo1.jpg	1	\N
3	https://frizerrose-images.fra1.digitaloceanspaces.com/1620728321995%20-%20101737139-styling-hair-by-smiling-male-hair-stylist-at-beauty-salon.jpg	\N	2
4	https://frizerrose-images.fra1.digitaloceanspaces.com/1620740803288%20-%20demo-lucija-horvat.jpg	\N	5
5	https://frizerrose-images.fra1.digitaloceanspaces.com/1620740925627%20-%20demo-marina-kovacic.jpg	\N	6
6	https://frizerrose-images.fra1.digitaloceanspaces.com/1620740934059%20-%20demo-luka-babic.jpg	\N	7
7	https://frizerrose-images.fra1.digitaloceanspaces.com/1622054514323%20-%20me.jpg	\N	13
12	https://frizerrose-images.fra1.digitaloceanspaces.com/1622055415836%20-%20apple-touch-icon.png	5	\N
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (id, status, date, "companyId") FROM stdin;
1	paid	2021-05-10	1
2	processing	2021-05-11	\N
3	processing	2021-05-11	1
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service (id, name, duration, price, sex, "companyId") FROM stdin;
1	Šišanje (muškarci)	30	50	both	\N
3	Šišanje (muškarci)	30	49	both	2
4	Šišanje (žene)	30	60	female	2
2	Šišanje (muškarci)	30	50	both	\N
5	dsfsdf	30	46	both	\N
6	Šišanje (muškarci)	30	60	both	1
7	Šišanje (žene)	45	120	female	1
8	Svečane frizure - vrlo duga kosa	75	350	both	3
9	Svečane frizure - duga kosa	60	275	both	3
10	Svečane frizure - srednje duga kosa	60	200	both	3
11	Svečane frizure - kratka kosa	45	125	both	3
12	Pranje + sušenje - kratka kosa	30	25	both	3
13	Pranje + sušenje - duga kosa	30	50	both	3
14	Vodena frizura - vrlo duga kosa	30	125	both	3
15	Vodena frizura - duga kosa	30	100	both	3
16	Vodena frizura - srednje duga kosa	30	75	both	3
17	Vodena frizura - duga kosa	30	100	both	3
18	Fen frizura - vrlo duga kosa	30	125	both	3
19	Fen frizura - duga kosa	30	100	both	3
20	Fen frizura - srednje duga kosa	30	75	both	3
21	Fen frizura - kratka kosa	30	50	both	3
22	Žensko šišanje - vrlo duga kosa	30	125	both	3
23	Žensko šišanje - duga kosa	30	100	both	3
24	Žensko šišanje - srednje duga kosa	30	75	both	3
25	Žensko šišanje - kratka kosa	30	50	both	3
26	Šišanje šiški	15	20	both	3
27	muško šišanje	30	50	both	4
29	Video poziv 30 minuta	30	0	both	5
28	Video poziv 60 minuta	60	0	both	5
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (id, name, "isPublic", email, hours, "companyId", "userId") FROM stdin;
1	Juraj Markešić	t	jurajmarkesic@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	1	1
2	Tomislav Ivanušević	t	tomislav@dolazim.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	2
3	Marko Ronik	t	marko@dolazim.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	3
4	Jurica Purica	t	juraj@dolazim.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	2	4
5	Lucija Horvat	t	marko.ronik@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	3	5
6	Marina Kovačić	t	demo-stranica-marina-kovacic@example.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	3	6
7	Luka Babić	t	demo-stranica-luka-babic@example.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	3	7
8	dhd	t	saddfs@sdf.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	8
9	Marin	f	test-demo-marina@dolazim.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	9
12	marko antic	t	1obicnimail@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	4	12
13	Marko Ronik	t	ronca85@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	5	13
14	Aleksandra Delač 	t	Alexoazaljepote@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	6	14
\.


--
-- Data for Name: staff_services_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff_services_service ("staffId", "serviceId") FROM stdin;
1	1
2	1
3	1
1	2
2	2
3	2
4	3
4	4
1	5
2	5
3	5
1	6
2	6
3	6
1	7
2	7
3	7
5	8
6	8
7	8
5	9
6	9
7	9
5	10
6	10
7	10
5	11
6	11
7	11
5	12
6	12
7	12
5	13
6	13
7	13
5	14
6	14
7	14
5	15
6	15
7	15
5	16
6	16
7	16
5	17
6	17
7	17
5	18
6	18
7	18
5	19
6	19
7	19
5	20
6	20
7	20
5	21
6	21
7	21
5	22
6	22
7	22
5	23
6	23
7	23
5	24
6	24
7	24
5	25
6	25
7	25
5	26
6	26
7	26
12	27
13	28
13	29
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, "isAdminAccount", password, "companyId") FROM stdin;
1	Juraj Markešić	jurajmarkesic@gmail.com	t	c47be035845314dbb17aac40689e028aa4445420f9381befe1c8a92eaeac93f6	1
3	Marko Ronik	marko@dolazim.hr	f	ca4d83ed336bb0f0730b6408f6f87ce2d0d35ef94e56f1e1bc18af45a966411e	1
4	Jurica Purica	juraj@dolazim.hr	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	2
6	Marina	demo-stranica-marina-kovacic@example.com	f	c8aad979fcc7d09193119ddbb813cbd4cd220ac9ebf1c44501ee2907b1533c1a	3
7	Luka	demo-stranica-luka-babic@example.com	f	558c2508244b180da36df32b28e5047e4a3ba52a4493a562e9a7a3f26705e1ea	3
2	Tomislav Ivanušević	tomislav@dolazim.hr	f	83f315de18a1c4d1e3883becf7270f4ec1474e8f83a693ed953c237105759dc1	1
8	dhd	saddfs@sdf.com	f	a61988a3c89358eec52033c3e77049b582a1d354d8a24749aa98191dcb6f9144	1
9	Marin	test-demo-marina@dolazim.hr	f	d9ec02028e1dacc31c4b84906517ee12260ad98007fa393bbbc3e027dcbab651	1
10	Tomislav	tomislav2@dolazim.hr	f	050e00a2570735471cb2d244601b523d8c4763f9037a822bb853a6b8c5702358	3
11	Juraj	juraj2@dolazim.hr	f	e5ff21e8f61968b50ade8a36d9763b0d520b2ff22d1066730da7e186461e4b1f	3
5	Lucija Horvat	marko.ronik@gmail.com	t	2fbd1516a1d7bc55d8feda8f2197b5fba2bc8238479d90229bb6d479469117ba	3
12	marko antic	1obicnimail@gmail.com	t	de0f6ed13b0913127e60a187c2faae94ec201f32d994e19f7ad4bd75e34c228c	4
13	Marko Ronik	ronca85@gmail.com	t	e90bbee999151acd4afad8ad50e5046363fa22c910a9828dac15f1e1e0d4a23c	5
14	Aleksandra Delač 	Alexoazaljepote@gmail.com	t	f79f0051175607ca22e6cebfbe02df69e30cbe43accba61cfa9b7b521ff611c0	6
15	Jurica Puricaasdas	saasdsasd@asdasd.com	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	\N
\.


--
-- Name: appointment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointment_id_seq', 7, true);


--
-- Name: break_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.break_id_seq', 1, false);


--
-- Name: companyPreferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."companyPreferences_id_seq"', 6, true);


--
-- Name: company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_id_seq', 6, true);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_id_seq', 8, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_seq', 4, true);


--
-- Name: dayOff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."dayOff_id_seq"', 1, false);


--
-- Name: faq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faq_id_seq', 1, false);


--
-- Name: image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.image_id_seq', 12, true);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_id_seq', 3, true);


--
-- Name: service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_id_seq', 29, true);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_id_seq', 14, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 15, true);


--
-- Name: company PK_056f7854a7afdba7cbd6d45fc20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT "PK_056f7854a7afdba7cbd6d45fc20" PRIMARY KEY (id);


--
-- Name: contact PK_2cbbe00f59ab6b3bb5b8d19f989; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT "PK_2cbbe00f59ab6b3bb5b8d19f989" PRIMARY KEY (id);


--
-- Name: service PK_85a21558c006647cd76fdce044b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT "PK_85a21558c006647cd76fdce044b" PRIMARY KEY (id);


--
-- Name: staff_services_service PK_88026c9cc44b3d320794d588a79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_services_service
    ADD CONSTRAINT "PK_88026c9cc44b3d320794d588a79" PRIMARY KEY ("staffId", "serviceId");


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: customer PK_a7a13f4cacb744524e44dfdad32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "PK_a7a13f4cacb744524e44dfdad32" PRIMARY KEY (id);


--
-- Name: companyPreferences PK_a7a5bec281a3c48b5ab5b4c8ef3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."companyPreferences"
    ADD CONSTRAINT "PK_a7a5bec281a3c48b5ab5b4c8ef3" PRIMARY KEY (id);


--
-- Name: image PK_d6db1ab4ee9ad9dbe86c64e4cc3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "PK_d6db1ab4ee9ad9dbe86c64e4cc3" PRIMARY KEY (id);


--
-- Name: faq PK_d6f5a52b1a96dd8d0591f9fbc47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faq
    ADD CONSTRAINT "PK_d6f5a52b1a96dd8d0591f9fbc47" PRIMARY KEY (id);


--
-- Name: break PK_dee8d87e7951042b63386ffc830; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break
    ADD CONSTRAINT "PK_dee8d87e7951042b63386ffc830" PRIMARY KEY (id);


--
-- Name: staff PK_e4ee98bb552756c180aec1e854a; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "PK_e4ee98bb552756c180aec1e854a" PRIMARY KEY (id);


--
-- Name: appointment PK_e8be1a53027415e709ce8a2db74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "PK_e8be1a53027415e709ce8a2db74" PRIMARY KEY (id);


--
-- Name: dayOff PK_ee1fa7ea22abc68cc42bc4268a4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."dayOff"
    ADD CONSTRAINT "PK_ee1fa7ea22abc68cc42bc4268a4" PRIMARY KEY (id);


--
-- Name: payment PK_fcaec7df5adf9cac408c686b2ab; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT "PK_fcaec7df5adf9cac408c686b2ab" PRIMARY KEY (id);


--
-- Name: image REL_147d4b76f8a2433c43f7f722c3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "REL_147d4b76f8a2433c43f7f722c3" UNIQUE ("staffId");


--
-- Name: image REL_63ae87e64b25d503974dee435b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "REL_63ae87e64b25d503974dee435b" UNIQUE ("companyId");


--
-- Name: companyPreferences REL_baffb5122f040e7eabff196ade; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."companyPreferences"
    ADD CONSTRAINT "REL_baffb5122f040e7eabff196ade" UNIQUE ("companyId");


--
-- Name: staff REL_eba76c23bcfc9dad2479b7fd2a; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "REL_eba76c23bcfc9dad2479b7fd2a" UNIQUE ("userId");


--
-- Name: company UQ_43558f6152bdfedab7b92e6a653; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT "UQ_43558f6152bdfedab7b92e6a653" UNIQUE ("contactEmail");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: company UQ_98f09f4fe6cec0d39f6e1eb93da; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT "UQ_98f09f4fe6cec0d39f6e1eb93da" UNIQUE ("bookingPageSlug");


--
-- Name: IDX_212c7ba88eca06bbfb5792f774; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_212c7ba88eca06bbfb5792f774" ON public.staff_services_service USING btree ("serviceId");


--
-- Name: IDX_42b67933b216d6143edb933eb6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_42b67933b216d6143edb933eb6" ON public.staff_services_service USING btree ("staffId");


--
-- Name: IDX_43558f6152bdfedab7b92e6a65; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_43558f6152bdfedab7b92e6a65" ON public.company USING btree ("contactEmail");


--
-- Name: IDX_902985a964245652d5e3a0f5f6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_902985a964245652d5e3a0f5f6" ON public.staff USING btree (email);


--
-- Name: IDX_98f09f4fe6cec0d39f6e1eb93d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_98f09f4fe6cec0d39f6e1eb93d" ON public.company USING btree ("bookingPageSlug");


--
-- Name: service FK_02fbdab4c697f74792472b88546; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT "FK_02fbdab4c697f74792472b88546" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: payment FK_0fe9e707d9586ed82ea31cabd17; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT "FK_0fe9e707d9586ed82ea31cabd17" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: image FK_147d4b76f8a2433c43f7f722c37; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "FK_147d4b76f8a2433c43f7f722c37" FOREIGN KEY ("staffId") REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: contact FK_196374b312744cf2c400c962383; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT "FK_196374b312744cf2c400c962383" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: staff_services_service FK_212c7ba88eca06bbfb5792f7745; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_services_service
    ADD CONSTRAINT "FK_212c7ba88eca06bbfb5792f7745" FOREIGN KEY ("serviceId") REFERENCES public.service(id) ON DELETE CASCADE;


--
-- Name: dayOff FK_3bccc232a4f042922d59c7f4602; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."dayOff"
    ADD CONSTRAINT "FK_3bccc232a4f042922d59c7f4602" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: staff_services_service FK_42b67933b216d6143edb933eb6b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_services_service
    ADD CONSTRAINT "FK_42b67933b216d6143edb933eb6b" FOREIGN KEY ("staffId") REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: image FK_63ae87e64b25d503974dee435bb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "FK_63ae87e64b25d503974dee435bb" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: users FK_6f9395c9037632a31107c8a9e58; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "FK_6f9395c9037632a31107c8a9e58" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: appointment FK_887d0cd9b48866fd1e269968f55; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "FK_887d0cd9b48866fd1e269968f55" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: break FK_96942094d3b808d56e3bfc85c95; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break
    ADD CONSTRAINT "FK_96942094d3b808d56e3bfc85c95" FOREIGN KEY ("staffId") REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: appointment FK_9c1066af3b6cc0f8c54de747b07; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "FK_9c1066af3b6cc0f8c54de747b07" FOREIGN KEY ("staffId") REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: customer FK_a9d874b83a7879be8538bf08b09; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "FK_a9d874b83a7879be8538bf08b09" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: companyPreferences FK_baffb5122f040e7eabff196adef; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."companyPreferences"
    ADD CONSTRAINT "FK_baffb5122f040e7eabff196adef" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: appointment FK_c048c6004b69354f46183f93a85; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "FK_c048c6004b69354f46183f93a85" FOREIGN KEY ("customerId") REFERENCES public.customer(id);


--
-- Name: appointment FK_cee8b55c31f700609674da96b0b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "FK_cee8b55c31f700609674da96b0b" FOREIGN KEY ("serviceId") REFERENCES public.service(id) ON DELETE CASCADE;


--
-- Name: staff FK_eb0137ccf80c181df8ca0b75c3c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "FK_eb0137ccf80c181df8ca0b75c3c" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: staff FK_eba76c23bcfc9dad2479b7fd2ad; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "FK_eba76c23bcfc9dad2479b7fd2ad" FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6 (Debian 12.6-1.pgdg100+1)
-- Dumped by pg_dump version 12.6 (Debian 12.6-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

