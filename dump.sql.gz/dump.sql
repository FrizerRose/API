--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE frizerrose;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md508cfe0a23f5d458787e4478c6c75158c';






--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6 (Debian 12.6-1.pgdg100+1)
-- Dumped by pg_dump version 12.6 (Debian 12.6-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "frizerrose" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6 (Debian 12.6-1.pgdg100+1)
-- Dumped by pg_dump version 12.6 (Debian 12.6-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: frizerrose; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE frizerrose WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE frizerrose OWNER TO postgres;

\connect frizerrose

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointment (
    id integer NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    message text NOT NULL,
    "hasSentStaffEmail" boolean DEFAULT false NOT NULL,
    "hasSentCustomerEmail" boolean DEFAULT false NOT NULL,
    "hasCustomerArrived" boolean DEFAULT true NOT NULL,
    "companyId" integer,
    "staffId" integer,
    "serviceId" integer,
    "customerId" integer
);


ALTER TABLE public.appointment OWNER TO postgres;

--
-- Name: appointment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointment_id_seq OWNER TO postgres;

--
-- Name: appointment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointment_id_seq OWNED BY public.appointment.id;


--
-- Name: break; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.break (
    id integer NOT NULL,
    start date NOT NULL,
    "end" date NOT NULL,
    "staffId" integer
);


ALTER TABLE public.break OWNER TO postgres;

--
-- Name: break_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.break_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.break_id_seq OWNER TO postgres;

--
-- Name: break_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.break_id_seq OWNED BY public.break.id;


--
-- Name: company; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    "bookingPageSlug" character varying(255) NOT NULL,
    oib character varying(255) DEFAULT ''::character varying NOT NULL,
    "contactEmail" character varying(255) DEFAULT ''::character varying NOT NULL,
    "streetName" character varying(255) DEFAULT ''::character varying NOT NULL,
    city character varying(255) DEFAULT ''::character varying NOT NULL,
    "phoneNumber" character varying(255) DEFAULT ''::character varying NOT NULL,
    about text DEFAULT ''::text NOT NULL,
    hours text NOT NULL
);


ALTER TABLE public.company OWNER TO postgres;

--
-- Name: companyPreferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."companyPreferences" (
    id integer NOT NULL,
    "leadTimeWindow" integer DEFAULT 3 NOT NULL,
    "schedulingWindow" integer DEFAULT 30 NOT NULL,
    "cancellationWindow" integer DEFAULT 2 NOT NULL,
    "hasStaffPick" boolean DEFAULT true NOT NULL,
    "hasSexPick" boolean DEFAULT false NOT NULL,
    "hasBorders" boolean DEFAULT false NOT NULL,
    "canCancel" boolean DEFAULT true NOT NULL,
    "showRules" boolean DEFAULT true NOT NULL,
    "showCoronaRules" boolean DEFAULT true NOT NULL,
    "clientReminderEmail" boolean DEFAULT true NOT NULL,
    "staffReminderEmail" boolean DEFAULT true NOT NULL,
    "staffCancellationNotice" boolean DEFAULT true NOT NULL,
    "isTutorialFinished" boolean DEFAULT false NOT NULL,
    "hasDarkMode" boolean DEFAULT false NOT NULL,
    "clientReminderTime" integer DEFAULT 2 NOT NULL,
    "staffReminderTime" integer DEFAULT 2 NOT NULL,
    "colorVariant" character varying(255) DEFAULT 'default'::character varying NOT NULL,
    "hasPattern" boolean DEFAULT false NOT NULL,
    "showTerms" boolean DEFAULT false NOT NULL,
    "facebookLink" character varying(255) DEFAULT ''::character varying NOT NULL,
    "instagramLink" character varying(255) DEFAULT ''::character varying NOT NULL,
    "websiteLink" character varying(255) DEFAULT ''::character varying NOT NULL,
    "termsText" text DEFAULT ''::text NOT NULL,
    rules text DEFAULT ''::text NOT NULL,
    "coronaRules" text DEFAULT ''::text NOT NULL,
    "companyId" integer
);


ALTER TABLE public."companyPreferences" OWNER TO postgres;

--
-- Name: companyPreferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."companyPreferences_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."companyPreferences_id_seq" OWNER TO postgres;

--
-- Name: companyPreferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."companyPreferences_id_seq" OWNED BY public."companyPreferences".id;


--
-- Name: company_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_id_seq OWNER TO postgres;

--
-- Name: company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.company_id_seq OWNED BY public.company.id;


--
-- Name: contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    body text NOT NULL,
    "companyId" integer
);


ALTER TABLE public.contact OWNER TO postgres;

--
-- Name: contact_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_id_seq OWNER TO postgres;

--
-- Name: contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_id_seq OWNED BY public.contact.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    phone character varying(255) DEFAULT ''::character varying NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    "companyId" integer
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_id_seq OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: dayOff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."dayOff" (
    id integer NOT NULL,
    start date NOT NULL,
    "end" date NOT NULL,
    "companyId" integer
);


ALTER TABLE public."dayOff" OWNER TO postgres;

--
-- Name: dayOff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."dayOff_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."dayOff_id_seq" OWNER TO postgres;

--
-- Name: dayOff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."dayOff_id_seq" OWNED BY public."dayOff".id;


--
-- Name: faq; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faq (
    id integer NOT NULL,
    question character varying(255) NOT NULL,
    answer text NOT NULL,
    category text DEFAULT ''::text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.faq OWNER TO postgres;

--
-- Name: faq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faq_id_seq OWNER TO postgres;

--
-- Name: faq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faq_id_seq OWNED BY public.faq.id;


--
-- Name: image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.image (
    id integer NOT NULL,
    link character varying(255) NOT NULL,
    "companyId" integer,
    "staffId" integer
);


ALTER TABLE public.image OWNER TO postgres;

--
-- Name: image_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.image_id_seq OWNER TO postgres;

--
-- Name: image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.image_id_seq OWNED BY public.image.id;


--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    id integer NOT NULL,
    date date NOT NULL,
    amount integer NOT NULL,
    "companyId" integer
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_id_seq OWNER TO postgres;

--
-- Name: payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_id_seq OWNED BY public.payment.id;


--
-- Name: service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    duration integer NOT NULL,
    price integer NOT NULL,
    sex character varying(255) DEFAULT 'both'::character varying NOT NULL,
    "companyId" integer
);


ALTER TABLE public.service OWNER TO postgres;

--
-- Name: service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_id_seq OWNER TO postgres;

--
-- Name: service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_id_seq OWNED BY public.service.id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    email character varying(255) NOT NULL,
    hours text NOT NULL,
    "companyId" integer,
    "userId" integer
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_id_seq OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_id_seq OWNED BY public.staff.id;


--
-- Name: staff_services_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_services_service (
    "staffId" integer NOT NULL,
    "serviceId" integer NOT NULL
);


ALTER TABLE public.staff_services_service OWNER TO postgres;

--
-- Name: userPreferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."userPreferences" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "userId" integer
);


ALTER TABLE public."userPreferences" OWNER TO postgres;

--
-- Name: userPreferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."userPreferences_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."userPreferences_id_seq" OWNER TO postgres;

--
-- Name: userPreferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."userPreferences_id_seq" OWNED BY public."userPreferences".id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "isAdminAccount" boolean DEFAULT false NOT NULL,
    password character varying(255) NOT NULL,
    "companyId" integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: appointment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment ALTER COLUMN id SET DEFAULT nextval('public.appointment_id_seq'::regclass);


--
-- Name: break id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break ALTER COLUMN id SET DEFAULT nextval('public.break_id_seq'::regclass);


--
-- Name: company id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company ALTER COLUMN id SET DEFAULT nextval('public.company_id_seq'::regclass);


--
-- Name: companyPreferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."companyPreferences" ALTER COLUMN id SET DEFAULT nextval('public."companyPreferences_id_seq"'::regclass);


--
-- Name: contact id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact ALTER COLUMN id SET DEFAULT nextval('public.contact_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: dayOff id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."dayOff" ALTER COLUMN id SET DEFAULT nextval('public."dayOff_id_seq"'::regclass);


--
-- Name: faq id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faq ALTER COLUMN id SET DEFAULT nextval('public.faq_id_seq'::regclass);


--
-- Name: image id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image ALTER COLUMN id SET DEFAULT nextval('public.image_id_seq'::regclass);


--
-- Name: payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment ALTER COLUMN id SET DEFAULT nextval('public.payment_id_seq'::regclass);


--
-- Name: service id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service ALTER COLUMN id SET DEFAULT nextval('public.service_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN id SET DEFAULT nextval('public.staff_id_seq'::regclass);


--
-- Name: userPreferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."userPreferences" ALTER COLUMN id SET DEFAULT nextval('public."userPreferences_id_seq"'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: appointment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointment (id, date, "time", message, "hasSentStaffEmail", "hasSentCustomerEmail", "hasCustomerArrived", "companyId", "staffId", "serviceId", "customerId") FROM stdin;
13	2021-04-06	10:00:00		f	f	t	1	2	1	1
11	2021-04-06	13:00:00		t	t	t	1	2	1	1
16	2021-04-08	08:45:00		t	t	t	1	2	1	5
14	2021-04-07	09:45:00		t	t	f	1	2	1	3
22	2021-04-08	10:00:00		f	f	t	1	3	1	8
19	2021-04-08	15:30:00	Tekst napomene	t	t	t	7	11	9	2
23	2021-04-08	15:45:00		t	t	t	1	3	1	1
17	2021-04-09	08:15:00	heya	t	t	t	1	2	1	5
20	2021-04-09	09:00:00		t	t	t	1	3	1	6
21	2021-04-09	09:00:00	Duga kosa	t	t	t	7	11	12	7
15	2021-04-11	09:45:00		t	t	t	1	1	2	5
24	2021-04-12	15:00:00	:) 	t	t	t	8	12	26	9
27	2021-04-13	09:30:00		t	t	t	1	2	1	1
40	2021-04-13	08:45:00		t	t	t	1	25	54	3
28	2021-04-13	10:00:00		t	t	t	1	25	54	10
42	2021-04-13	10:30:00		t	t	t	1	25	54	1
43	2021-04-13	10:45:00		t	t	t	1	25	54	1
29	2021-04-13	11:00:00		t	t	t	1	25	54	11
32	2021-04-13	12:30:00		t	t	t	1	25	54	1
35	2021-04-13	13:15:00		t	t	t	1	25	54	1
37	2021-04-13	14:15:00		t	t	t	1	25	54	12
36	2021-04-13	15:00:00		t	t	t	1	25	54	1
44	2021-04-13	15:30:00	fg	t	t	t	1	25	50	14
38	2021-04-13	15:45:00		t	t	t	1	25	54	11
39	2021-04-13	17:00:00		t	t	t	1	25	54	11
30	2021-04-14	11:45:00		t	t	t	1	25	54	12
9	2021-04-14	13:30:00	2222	t	t	t	1	3	2	2
41	2021-04-14	15:00:00		t	t	t	1	25	54	13
10	2021-04-14	18:30:00	2222	t	t	t	1	3	2	2
26	2021-04-15	08:00:00	ništa	t	t	t	12	21	42	5
2	2021-04-15	10:15:00	123	t	t	t	1	3	2	2
31	2021-04-15	10:45:00		t	t	t	1	25	54	10
33	2021-04-15	12:45:00		t	t	t	1	25	54	1
18	2021-04-16	10:15:00		t	t	t	1	1	3	1
4	2021-04-16	10:30:00	aaaaaa	t	t	t	1	3	2	2
5	2021-04-16	11:30:00	2222	t	t	t	1	3	2	2
34	2021-04-16	11:45:00		t	t	t	1	25	50	10
25	2021-04-17	10:15:00		t	t	t	12	18	44	5
7	2021-04-17	11:00:00	2222	t	t	t	1	3	2	2
45	2021-04-22	09:15:00		t	t	t	1	25	54	1
\.


--
-- Data for Name: break; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.break (id, start, "end", "staffId") FROM stdin;
\.


--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company (id, name, "isPublic", "bookingPageSlug", oib, "contactEmail", "streetName", city, "phoneNumber", about, hours) FROM stdin;
1	Frizerski Salon Trešnja	t	tresnja		juraj@dolazim.hr					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"12:00"},{"start":"13:00","end":"17:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
2	Frizerski Salon Čokolada	t	čokolada		jurajerepublic@gmail.com					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"12:00"},{"start":"13:00","end":"17:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
3	Frizerski Salon Puričani	t	puričani		jurica@purica123.com					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"12:00"},{"start":"13:00","end":"17:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
4	Frizersi Salon Bojo	t	bojo		bojo@rojo123.com					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"12:00"},{"start":"13:00","end":"17:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
10	sdfsdf	t	dsfsd		aaaasda@sdfsf.com					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
8	Studio za masažu "Lotta"	t	lotta		crkvenac.zeljka95@gmail.com	Milana Sufflaya 2 A	Bjelovar		Studio koji nudi kvalitetne i nadasve potrebne fizioterapeutske tretmane,procjenu i pomoć, a uz to i vrhunske masaže.\nDođite i uvijerite se sami u naše znanje i vještine.	{"monday":{"active":true,"shifts":[{"start":"09:00","end":"14:00"},{"start":"14:30","end":"20:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
6	Masaža Ivo	t	ivo		info@dolazim.hr					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
5	Frizerski Salon Monika	t	monique		eskejpth@gmail.com	Trg Bana Jelačića 1	Zagreb	385990012345	Ovo je kratki tekst o nama, nadamo se uspješnoj suradnji i brzim rezervacijama.	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
7	Barber Shop Monika	t	monika		moonyey@gmail.com	Trg Bana Jelačića 1	Zagreb	0991234568	Ovo je kratki tekst o nama, nadamo se uspješnoj suradnji i brzim rezervacijama.	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
12	Superwash	t	superwash		marko.ronik@gmail.com					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
9	sldkflsk df lskdjfk	t	kravice		ivan@ivansdas.com					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
11	sdfsdfdsfsdf	t	fgdgdsdfsd		jurajmarkesic2@gmail.com					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
13	sdfsdfsdfsd	t	fsdfsfdf		sdfsdf@sdljhfd.com					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
14	sdfsdfsdsdfs	t	dfsdffsdfsdf		sdfsdf@sdfdsf.co					{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}
\.


--
-- Data for Name: companyPreferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."companyPreferences" (id, "leadTimeWindow", "schedulingWindow", "cancellationWindow", "hasStaffPick", "hasSexPick", "hasBorders", "canCancel", "showRules", "showCoronaRules", "clientReminderEmail", "staffReminderEmail", "staffCancellationNotice", "isTutorialFinished", "hasDarkMode", "clientReminderTime", "staffReminderTime", "colorVariant", "hasPattern", "showTerms", "facebookLink", "instagramLink", "websiteLink", "termsText", rules, "coronaRules", "companyId") FROM stdin;
2	3	30	2	t	f	f	t	t	t	t	t	t	f	f	2	2	default	f	f							2
5	3	30	2	t	t	f	t	t	t	t	t	t	t	f	2	2	default	t	f					Molimo vas da rezervaciju otkažete na vrijeme, u suprutnom ista će biti naplaćena pri sljedećem terminu.	Molimo ponesite masku, i držite se propisanih COVID-19 mjera.	5
8	24	30	4	t	f	f	t	t	t	t	t	t	t	f	4	2	orchid	t	f	https://www.facebook.com/studiozamasazuLotta						8
9	3	30	2	t	f	f	t	t	t	t	t	t	t	f	2	2	default	f	f							9
10	3	30	2	t	f	f	t	t	t	t	t	t	t	f	2	2	default	f	f							10
11	3	30	2	t	f	f	t	t	t	t	t	t	f	f	2	2	default	f	f							11
13	3	30	2	t	f	f	t	t	t	t	t	t	f	f	2	2	default	f	f							13
14	3	30	2	t	f	f	t	t	t	t	t	t	f	f	2	2	default	f	f							14
3	3	30	2	t	f	f	t	t	t	t	t	t	f	f	2	2	default	f	f							3
12	3	30	2	f	f	t	t	t	t	t	t	t	t	f	2	2	default	f	f							12
4	3	30	2	t	f	f	t	t	t	t	t	t	t	f	2	2	default	f	f							4
6	3	30	2	t	f	f	t	t	t	t	t	t	t	f	2	2	default	f	f							6
1	3	30	2	t	t	f	t	t	t	t	t	t	t	f	2	2	coral	t	t				skjdhfkjshjkdf sf\nsd\nf s\nd \nsd \nfs d\nf\n 			1
7	3	30	2	t	t	f	t	t	t	t	t	t	f	f	2	2	coral	t	f					Molimo vas da rezervaciju otkažete na vrijeme, u suprutnom ista će biti naplaćena pri sljedećem terminu.	Molimo ponesite masku, i držite se propisanih COVID-19 mjera.\n	7
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact (id, name, email, body, "companyId") FROM stdin;
1	Frizerski Salon Trešnja	jurajmarkesic@gmail.com	Testna poruka aaa	1
2	Frizerski Salon Trešnja	jurajmarkesic@gmail.com	sfsfs	1
3	Frizerski Salon Trešnja	marko.ronik@gmail.com	imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje imam problem test mail s trešnje 	1
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, name, email, phone, notes, "companyId") FROM stdin;
4	Juraj Markešić	dfs@dola.comd	4354		5
2	Korisnik 1	eskejpth@gmail.com	0998167150		7
6	novi test	novitest@novitest.nt			1
7	Lidija	logx64@gmail.com	0998167520		7
8	a				1
9	Amalija Kranjec Markešić	amalija.kranjec.m@gmail.com	+385997344800		8
5	Olga Brezovska	ronca85@gmail.com	mob		12
10	sfsdfsd	sdfsdf@dsfkjd.com			1
12	sddfsdfg	sdfsdf@dsfkjd.csdfom			1
11	sdfs	sdfsfdfddf@dsfkjd.com			1
3	Marko Ronik	marko@dolazim.hr	234234		1
13	sdfsdf@dsfkjd.com	sdsfdfsdfs@dsfkjd.com			1
14	Juraj Markešić	jurajmarkesffic@gmail.com	0953984635		1
1	Juraj Markešić	jurajmarkesic@gmail.com	0953984635		1
\.


--
-- Data for Name: dayOff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."dayOff" (id, start, "end", "companyId") FROM stdin;
2	2021-01-01	2021-01-02	8
1	2021-01-01	2021-04-02	\N
\.


--
-- Data for Name: faq; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faq (id, question, answer, category, "order") FROM stdin;
1	Gdje moji klijenti mogu zakazati termin?	Vaši klijenti mogu zakazati termin na vašoj stranici za rezervacije koja glasi <imesalona>.dolazim.hr. Uz rezervaciju, vaši će klijenti moći vidjeti i popis usluga te osnovne informacije o vama.		0
2	Mogu li unijeti radno vrijeme i neradne dane?	Klikom na "Postavke" te "Radno vrijeme" možete podesiti radno vrijeme i neradne dane. Svaki dan u tjednu se može posebno podesiti, te se može dodati smjenski rad. 		1
3	Koliko usluga mogu dodati?	Broj usluga je neograničen, sve usluge imaju mogućnost odabira djelatnika koji ih pruža.		2
4	Kako mogu ručno upisati termin?	Klikom na "Kalendar" u meniju otvoriti će se Kalendar s prikazom trenutnog tjedna. Kako bi upisali termin ručno, pronađite željeni datum i klikom označite željeno vrijeme, otvoriti će se izbornik za popunjavanje termina u kojem možete unijeti sve potrebne detalje.	Termini	0
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.image (id, link, "companyId", "staffId") FROM stdin;
2	https://frizerrose-images.fra1.digitaloceanspaces.com/1617635477537%20-%20Paris_Most_Famous_Hairstylist_on_French_Hair_01.jpg	\N	1
4	https://frizerrose-images.fra1.digitaloceanspaces.com/1617635493863%20-%20101737139-styling-hair-by-smiling-male-hair-stylist-at-beauty-salon.jpg	\N	3
8	https://frizerrose-images.fra1.digitaloceanspaces.com/1617710592334%20-%20sassy-meloun.png	\N	2
9	https://frizerrose-images.fra1.digitaloceanspaces.com/1617797835152%20-%20barber-shop-logo.jpg	\N	\N
10	https://frizerrose-images.fra1.digitaloceanspaces.com/1617869496465%20-%20barber-shop-logo.jpg	\N	\N
11	https://frizerrose-images.fra1.digitaloceanspaces.com/1617869603357%20-%20barber-shop-logo.jpg	\N	\N
12	https://frizerrose-images.fra1.digitaloceanspaces.com/1617869630261%20-%20barber-shop-logo1.jpg	\N	\N
15	https://frizerrose-images.fra1.digitaloceanspaces.com/1617869797826%20-%20barber-shop-logo1.jpg	\N	\N
16	https://frizerrose-images.fra1.digitaloceanspaces.com/1617869807864%20-%201617869732555%20-%20hair.jpg	\N	\N
17	https://frizerrose-images.fra1.digitaloceanspaces.com/1617869937156%20-%20barber-shop-logo1.jpg	1	\N
18	https://frizerrose-images.fra1.digitaloceanspaces.com/1617871374761%20-%20barber-shop-logo1.jpg	\N	\N
19	https://frizerrose-images.fra1.digitaloceanspaces.com/1617871404941%20-%20barber-shop-logo1.jpg	7	\N
20	https://frizerrose-images.fra1.digitaloceanspaces.com/1617891251787%20-%20lotta.jpg	8	\N
21	https://frizerrose-images.fra1.digitaloceanspaces.com/1617892889868%20-%20maser2.jpg	\N	14
22	https://frizerrose-images.fra1.digitaloceanspaces.com/1617892899755%20-%20maser1.jpg	\N	13
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (id, date, amount, "companyId") FROM stdin;
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service (id, name, duration, price, sex, "companyId") FROM stdin;
1	Šišanje (muškarci)	30	50	male	1
2	Šišanje (žene)	30	100	both	1
3	Pranje kose	15	20	both	1
5	Šišanje + pranje kose	60	120	both	5
6	Šišanje i brijanje	60	100	male	5
7	Šišanje i farbanje	120	250	both	5
4	Šišanje	30	30	male	5
8	Farbanje kose	120	200	both	5
10	Šišanje i brijanje	60	100	male	7
11	Farbanje kose	120	220	female	7
12	Šišanje i farbanje	120	280	female	7
9	Šišanje	30	80	both	7
14	Brijanje	30	100	female	\N
25	Maderoterapija	45	110	both	\N
26	Maderoterapija	45	110	both	8
27	Primjer Usluge 1	60	100	both	8
28	Primjer Usluge 2	75	200	both	\N
29	Abrakdaabra	30	50	both	9
30	Bojanje trepavica	90	123	both	10
36	Unutarnje pranje	15	40	both	12
37	Vanjsko pranje	30	40	both	12
38	Kompletno pranje	45	60	both	12
39	Premaz voskom + pranje	60	200	both	12
40	Pranje motora	30	40	both	12
41	Poliranje vozila	45	600	both	12
42	Kemijsko čišćenje	30	400	both	12
43	Kemijsko čišćenje po elementu/sjedalu	15	100	both	12
44	Priprema vozila za prodaju (poliranje, kemijsko, pranje motora, štokova)	90	900	both	12
45	cxvdxdfg	30	59	both	1
46	sdgsdgdf	30	100	both	1
47	sfsd	30	100	both	1
48	sdfsd fsd f sdf	30	100	both	1
49	sfsdfds	30	100	both	1
50	cxgdfg dfg 	30	100	both	1
51	aaaaaaaa	30	100	both	1
52	vsdf sdf sd 	30	100	both	1
53	g d fg fg	30	100	both	1
54	dfgdfgdfg	30	100	both	1
55	erterter	30	100	both	1
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (id, name, "isPublic", email, hours, "companyId", "userId") FROM stdin;
4	jurajerepublic@gmail.com	t	jurajerepublic@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	2	4
5	Jurica Purica	t	jurica@purica123.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	3	5
6	Bojo Rojo	t	bojo@rojo123.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	4	6
7	Monika Demo	t	eskejpth@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	5	7
8	Ivan Marulić	t	info@dolazim.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	6	8
9	Tomislav	t	logx64@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	5	9
10	Monika Demo	t	moonyey@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	7	10
11	Tomislav	t	tomislav.ivanusevic@me.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	7	11
1	jurajmarkesic@gmail.com	t	juraj@dolazim.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"15:45"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	1	1
12	Željka Crkvenac	t	crkvenac.zeljka95@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	8	12
13	Primjer Radnika 1	t	radnik@test123.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":false,"shifts":[]}}	8	13
2	Marko Ronik	t	marko@dolazim.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"15:45"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	2
14	Primjer Radnika 2	t	radnik2@test123.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	8	14
3	Tomislav Ivanušević	t	tomislav@dolazim.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"15:45"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	3
15	Ivan Ivanovic	t	ivan@ivansdas.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	9	15
16	josko bogar	t	aaaasda@sdfsf.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	10	16
17	sddfdsfs	t	jurajmarkesic2@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	11	17
18	Marko Ronik Autopraonik	t	marko.ronik@gmail.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	12	18
19	dskljfld dskjfs 	t	sdfsdf@sdljhfd.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	13	19
20	Jurica Puricasdfs	t	sdfsdf@sdfdsf.co	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"sunday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]}}	14	20
21	Ante Antić	t	anteantic@anteanticsuperwash.hr	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	12	21
22	asdas	t	dasdasd@sdf.comf	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	22
23	sdfsdfsd	t	fsdfsdf@dssfsdf.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	23
24	fsdfsdfsdfs dfs df	t	sdfsdfsd@sdfsd.comf	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	24
25	cxgfvsdfsdf	t	sdfsdfsf@dfkjdks.comf	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	25
26	vdfgdfgd	t	fdgfgdgdfg@dsfkslsjf.com	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	26
27	fsdfsdf	t	sdfsd@sdfsdfsd.fsd	{"monday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"tuesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"wednesday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"thursday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"friday":{"active":true,"shifts":[{"start":"08:00","end":"16:00"}]},"saturday":{"active":false,"shifts":[]},"sunday":{"active":false,"shifts":[]}}	1	27
\.


--
-- Data for Name: staff_services_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff_services_service ("staffId", "serviceId") FROM stdin;
1	1
3	1
1	2
2	2
3	2
1	3
2	3
3	3
7	4
7	5
7	6
7	7
7	8
9	4
9	6
9	5
11	9
10	9
11	10
10	10
11	11
10	11
11	12
10	12
11	14
10	14
2	1
12	25
12	26
14	26
12	27
13	27
14	27
13	26
14	28
13	28
12	28
15	29
16	30
18	36
18	37
18	38
18	39
18	40
18	41
18	42
18	43
18	44
21	43
21	42
21	41
21	40
21	39
21	38
21	37
21	36
21	44
26	1
26	3
26	2
2	45
1	45
3	45
22	45
23	45
24	45
25	45
26	45
27	45
2	46
1	46
3	46
22	46
23	46
24	46
25	46
26	46
27	46
2	47
1	47
3	47
22	47
23	47
24	47
25	47
26	47
27	47
2	50
1	50
3	50
22	50
23	50
24	50
25	50
26	50
27	50
2	51
1	51
3	51
22	51
23	51
24	51
25	51
26	51
27	51
2	52
1	52
3	52
22	52
23	52
24	52
25	52
26	52
27	52
2	53
1	53
3	53
22	53
23	53
24	53
25	53
26	53
27	53
2	54
1	54
3	54
22	54
23	54
24	54
25	54
26	54
27	54
2	55
1	55
3	55
22	55
23	55
24	55
25	55
26	55
27	55
\.


--
-- Data for Name: userPreferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."userPreferences" (id, name, "userId") FROM stdin;
1	default	1
2	default	2
3	default	3
4	default	4
5	default	5
6	default	6
7	default	7
8	default	8
9	default	9
10	default	10
11	default	11
12	default	12
13	default	13
14	default	14
15	default	15
16	default	16
17	default	17
18	default	18
19	default	19
20	default	20
21	default	21
22	default	22
23	default	23
24	default	24
25	default	25
26	default	26
27	default	27
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, "isAdminAccount", password, "companyId") FROM stdin;
1	jurajmarkesic@gmail.com	juraj@dolazim.hr	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	1
3	Tomislav Ivanušević	tomislav@dolazim.hr	f	f2a39f44c4f6d05a605a005ab9e9cf3c5aeddf99f5c91527944ec3a339a7878b	1
4	jurajerepublic@gmail.com	jurajerepublic@gmail.com	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	2
5	Jurica Purica	jurica@purica123.com	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	3
6	Bojo Rojo	bojo@rojo123.com	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	4
8	Ivan Marulić	info@dolazim.hr	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	6
7	Monika Demo	eskejpth@gmail.com	t	f7368f2e26240a760c0ce876b763f25fa42cf0301929638e7ced3695af9344ed	5
9	Tomislav	logx64@gmail.com	f	77825f885ed033f1665aa0303933cee716f829bc1495102103e013230034c855	5
10	Monika Demo	moonyey@gmail.com	t	83a685b3fb644cc170b3e435449acd8ce4d9b16404010fb60e5bea8e0ce201d1	7
11	Tomislav	tomislav.ivanusevic@me.com	f	e50e0832094b9cc90e4ca1963ed21e0a679395d39b8476098e3a3e98ed5a0e1c	7
12	Željka Crkvenac	crkvenac.zeljka95@gmail.com	t	b62d5e7817323bfc2952c8fd7cd761f9564e45dd27c4b32b9bbf1d2cee7bb390	8
13	Primjer Radnika 1	radnik@test123.hr	f	99a4dcf32a7e232da01b40ab39933de902958fbe6733fd422062dd35337a4c90	8
14	Primjer Radnika 2	radnik2@test123.hr	f	e3f8960a0f91d1a75775f1b97b0c690769e4f90562c114c97a83e1e296879bf2	8
15	Ivan Ivanovic	ivan@ivansdas.com	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	9
16	josko bogar	aaaasda@sdfsf.com	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	10
17	sddfdsfs	jurajmarkesic2@gmail.com	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	11
18	Marko Ronik Autopraonik	marko.ronik@gmail.com	t	09dec93d6250e1d1d5c84eba241c8b0faa2c242a69f019f5432199ba3f0859e4	12
19	dskljfld dskjfs 	sdfsdf@sdljhfd.com	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	13
20	Jurica Puricasdfs	sdfsdf@sdfdsf.co	t	dbc3254f2d0a8d1833237b01d577461a185d045579ed548e8365333cc00def70	14
21	Ante Antić	anteantic@anteanticsuperwash.hr	f	26f8d8f26498b135fb34d51e500360e6f83971d24956a87c2485769011bc338d	12
22	asdas	dasdasd@sdf.comf	f	84d087840a0136185c2056dfeff352968a04a614a57802cc3fe1a27cf806ae5d	1
23	sdfsdfsd	fsdfsdf@dssfsdf.com	f	e40693a82270ceecd6f5619bfd4b034434e9a3dae3f68784d8e318a479f7f6e5	1
24	fsdfsdfsdfs dfs df	sdfsdfsd@sdfsd.comf	f	8d0a7acf9a84b45ef6a3ee4bd05c15153dd33e53c71784371a4c963949a249bb	1
25	cxgfvsdfsdf	sdfsdfsf@dfkjdks.comf	f	fc4f2a81fc49778acacdcc1c67c6590d1e6c78786f31ff914d03388f5a9f6bbb	1
26	vdfgdfgd	fdgfgdgdfg@dsfkslsjf.com	f	56a0b58ed429f0c2a2f21070471c20c770cce0baab3fb9abc4d4ae345d270a4f	1
27	fsdfsdf	sdfsd@sdfsdfsd.fsd	f	4b172b6d22e46e171768f79f7eca74c35f52bbd65b7b49a3f20dc06b031f367b	1
2	Marko Ronik	marko@dolazim.hr	f	09dec93d6250e1d1d5c84eba241c8b0faa2c242a69f019f5432199ba3f0859e4	1
\.


--
-- Name: appointment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointment_id_seq', 45, true);


--
-- Name: break_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.break_id_seq', 1, false);


--
-- Name: companyPreferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."companyPreferences_id_seq"', 14, true);


--
-- Name: company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_id_seq', 14, true);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_id_seq', 3, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_seq', 14, true);


--
-- Name: dayOff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."dayOff_id_seq"', 2, true);


--
-- Name: faq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faq_id_seq', 4, true);


--
-- Name: image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.image_id_seq', 22, true);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_id_seq', 1, false);


--
-- Name: service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_id_seq', 55, true);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_id_seq', 27, true);


--
-- Name: userPreferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."userPreferences_id_seq"', 27, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 27, true);


--
-- Name: company PK_056f7854a7afdba7cbd6d45fc20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT "PK_056f7854a7afdba7cbd6d45fc20" PRIMARY KEY (id);


--
-- Name: contact PK_2cbbe00f59ab6b3bb5b8d19f989; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT "PK_2cbbe00f59ab6b3bb5b8d19f989" PRIMARY KEY (id);


--
-- Name: service PK_85a21558c006647cd76fdce044b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT "PK_85a21558c006647cd76fdce044b" PRIMARY KEY (id);


--
-- Name: staff_services_service PK_88026c9cc44b3d320794d588a79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_services_service
    ADD CONSTRAINT "PK_88026c9cc44b3d320794d588a79" PRIMARY KEY ("staffId", "serviceId");


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: customer PK_a7a13f4cacb744524e44dfdad32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "PK_a7a13f4cacb744524e44dfdad32" PRIMARY KEY (id);


--
-- Name: companyPreferences PK_a7a5bec281a3c48b5ab5b4c8ef3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."companyPreferences"
    ADD CONSTRAINT "PK_a7a5bec281a3c48b5ab5b4c8ef3" PRIMARY KEY (id);


--
-- Name: userPreferences PK_ab832218e01c883d2d0395f13fb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."userPreferences"
    ADD CONSTRAINT "PK_ab832218e01c883d2d0395f13fb" PRIMARY KEY (id);


--
-- Name: image PK_d6db1ab4ee9ad9dbe86c64e4cc3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "PK_d6db1ab4ee9ad9dbe86c64e4cc3" PRIMARY KEY (id);


--
-- Name: faq PK_d6f5a52b1a96dd8d0591f9fbc47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faq
    ADD CONSTRAINT "PK_d6f5a52b1a96dd8d0591f9fbc47" PRIMARY KEY (id);


--
-- Name: break PK_dee8d87e7951042b63386ffc830; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break
    ADD CONSTRAINT "PK_dee8d87e7951042b63386ffc830" PRIMARY KEY (id);


--
-- Name: staff PK_e4ee98bb552756c180aec1e854a; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "PK_e4ee98bb552756c180aec1e854a" PRIMARY KEY (id);


--
-- Name: appointment PK_e8be1a53027415e709ce8a2db74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "PK_e8be1a53027415e709ce8a2db74" PRIMARY KEY (id);


--
-- Name: dayOff PK_ee1fa7ea22abc68cc42bc4268a4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."dayOff"
    ADD CONSTRAINT "PK_ee1fa7ea22abc68cc42bc4268a4" PRIMARY KEY (id);


--
-- Name: payment PK_fcaec7df5adf9cac408c686b2ab; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT "PK_fcaec7df5adf9cac408c686b2ab" PRIMARY KEY (id);


--
-- Name: image REL_147d4b76f8a2433c43f7f722c3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "REL_147d4b76f8a2433c43f7f722c3" UNIQUE ("staffId");


--
-- Name: userPreferences REL_4f8d527eeb2409b3f726535b1e; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."userPreferences"
    ADD CONSTRAINT "REL_4f8d527eeb2409b3f726535b1e" UNIQUE ("userId");


--
-- Name: image REL_63ae87e64b25d503974dee435b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "REL_63ae87e64b25d503974dee435b" UNIQUE ("companyId");


--
-- Name: companyPreferences REL_baffb5122f040e7eabff196ade; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."companyPreferences"
    ADD CONSTRAINT "REL_baffb5122f040e7eabff196ade" UNIQUE ("companyId");


--
-- Name: staff REL_eba76c23bcfc9dad2479b7fd2a; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "REL_eba76c23bcfc9dad2479b7fd2a" UNIQUE ("userId");


--
-- Name: company UQ_43558f6152bdfedab7b92e6a653; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT "UQ_43558f6152bdfedab7b92e6a653" UNIQUE ("contactEmail");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: company UQ_98f09f4fe6cec0d39f6e1eb93da; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT "UQ_98f09f4fe6cec0d39f6e1eb93da" UNIQUE ("bookingPageSlug");


--
-- Name: IDX_212c7ba88eca06bbfb5792f774; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_212c7ba88eca06bbfb5792f774" ON public.staff_services_service USING btree ("serviceId");


--
-- Name: IDX_42b67933b216d6143edb933eb6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_42b67933b216d6143edb933eb6" ON public.staff_services_service USING btree ("staffId");


--
-- Name: service FK_02fbdab4c697f74792472b88546; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT "FK_02fbdab4c697f74792472b88546" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: payment FK_0fe9e707d9586ed82ea31cabd17; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT "FK_0fe9e707d9586ed82ea31cabd17" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: image FK_147d4b76f8a2433c43f7f722c37; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "FK_147d4b76f8a2433c43f7f722c37" FOREIGN KEY ("staffId") REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: contact FK_196374b312744cf2c400c962383; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT "FK_196374b312744cf2c400c962383" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: staff_services_service FK_212c7ba88eca06bbfb5792f7745; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_services_service
    ADD CONSTRAINT "FK_212c7ba88eca06bbfb5792f7745" FOREIGN KEY ("serviceId") REFERENCES public.service(id) ON DELETE CASCADE;


--
-- Name: dayOff FK_3bccc232a4f042922d59c7f4602; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."dayOff"
    ADD CONSTRAINT "FK_3bccc232a4f042922d59c7f4602" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: staff_services_service FK_42b67933b216d6143edb933eb6b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_services_service
    ADD CONSTRAINT "FK_42b67933b216d6143edb933eb6b" FOREIGN KEY ("staffId") REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: userPreferences FK_4f8d527eeb2409b3f726535b1e3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."userPreferences"
    ADD CONSTRAINT "FK_4f8d527eeb2409b3f726535b1e3" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: image FK_63ae87e64b25d503974dee435bb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT "FK_63ae87e64b25d503974dee435bb" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: users FK_6f9395c9037632a31107c8a9e58; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "FK_6f9395c9037632a31107c8a9e58" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: appointment FK_887d0cd9b48866fd1e269968f55; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "FK_887d0cd9b48866fd1e269968f55" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: break FK_96942094d3b808d56e3bfc85c95; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break
    ADD CONSTRAINT "FK_96942094d3b808d56e3bfc85c95" FOREIGN KEY ("staffId") REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: appointment FK_9c1066af3b6cc0f8c54de747b07; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "FK_9c1066af3b6cc0f8c54de747b07" FOREIGN KEY ("staffId") REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: customer FK_a9d874b83a7879be8538bf08b09; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "FK_a9d874b83a7879be8538bf08b09" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: companyPreferences FK_baffb5122f040e7eabff196adef; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."companyPreferences"
    ADD CONSTRAINT "FK_baffb5122f040e7eabff196adef" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: appointment FK_c048c6004b69354f46183f93a85; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "FK_c048c6004b69354f46183f93a85" FOREIGN KEY ("customerId") REFERENCES public.customer(id);


--
-- Name: appointment FK_cee8b55c31f700609674da96b0b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT "FK_cee8b55c31f700609674da96b0b" FOREIGN KEY ("serviceId") REFERENCES public.service(id) ON DELETE CASCADE;


--
-- Name: staff FK_eb0137ccf80c181df8ca0b75c3c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "FK_eb0137ccf80c181df8ca0b75c3c" FOREIGN KEY ("companyId") REFERENCES public.company(id) ON DELETE CASCADE;


--
-- Name: staff FK_eba76c23bcfc9dad2479b7fd2ad; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "FK_eba76c23bcfc9dad2479b7fd2ad" FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6 (Debian 12.6-1.pgdg100+1)
-- Dumped by pg_dump version 12.6 (Debian 12.6-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

